"""
mock_data.py
Solo se ejecuta si la colección está vacía.
"""

import logging
import os

logger = logging.getLogger(__name__)


MOCK_CONVERSATIONS = [
    {
        "conv_id": "CONV-0001", "user_id": "USR-00042", "num_turnos": 3, "cluster_id": 1,
        "texto_completo": (
            "Usuario: ¿Cómo puedo diferir una compra en mi tarjeta de crédito?\n"
            "Asistente: En la app ve a Tarjetas → selecciona el cargo → Diferir.\n"
            "Usuario: ¿Cuántos meses puedo elegir?\n"
            "Asistente: 3, 6, 9 o 12 meses para compras mayores a $500 MXN.\n"
            "Usuario: Perfecto, muchas gracias.\nAsistente: Con gusto, ¿algo más?"
        ),
    },
    {
        "conv_id": "CONV-0002", "user_id": "USR-00099", "num_turnos": 2, "cluster_id": 4,
        "texto_completo": (
            "Usuario: ¿Qué opciones de inversión tienen?\n"
            "Asistente: Fondo Hey al 11.5% TIIE anual, CETES desde $100 y Fondos de Inversión.\n"
            "Usuario: ¿El Fondo Hey tiene plazo mínimo?\n"
            "Asistente: No, es líquido. Retiras cuando quieras sin penalización."
        ),
    },
    {
        "conv_id": "CONV-0003", "user_id": "USR-00015", "num_turnos": 4, "cluster_id": 0,
        "texto_completo": (
            "Usuario: Tuve un problema con una transferencia, no llegó el dinero.\n"
            "Asistente: ¿Me puedes indicar la fecha y el monto?\n"
            "Usuario: Fue ayer por $3,500 pesos al banco BBVA.\n"
            "Asistente: Los SPEI pueden tardar 24h. ¿Tienes el número de rastreo CECOBAN?\n"
            "Usuario: No lo tengo.\n"
            "Asistente: Lo encuentras en: Movimientos → selecciona la transferencia → Ver comprobante."
        ),
    },
    {
        "conv_id": "CONV-0004", "user_id": "USR-00042", "num_turnos": 2, "cluster_id": 1,
        "texto_completo": (
            "Usuario: ¿Cuál es mi límite de crédito actual?\n"
            "Asistente: Tu límite es $45,000 MXN con 38% de utilización.\n"
            "Usuario: ¿Puedo solicitar un aumento?\n"
            "Asistente: Sí, ve a Tarjetas → Solicitar aumento. Con tu historial podrías llegar a $60,000 MXN."
        ),
    },
    {
        "conv_id": "CONV-0005", "user_id": "USR-00078", "num_turnos": 3, "cluster_id": 3,
        "texto_completo": (
            "Usuario: ¿Cuándo llega mi remesa de Estados Unidos?\n"
            "Asistente: Las remesas se acreditan en máximo 2 días hábiles.\n"
            "Usuario: ¿Qué tipo de cambio aplican?\n"
            "Asistente: Tipo de cambio interbancario del día, sin comisión de recepción.\n"
            "Usuario: Gracias.\nAsistente: ¡Con gusto!"
        ),
    },
    {
        "conv_id": "CONV-0006", "user_id": "USR-00033", "num_turnos": 2, "cluster_id": 2,
        "texto_completo": (
            "Usuario: Acabo de abrir mi cuenta, ¿cómo activo mi tarjeta?\n"
            "Asistente: App → Tarjetas → Activar tarjeta → ingresa los últimos 4 dígitos.\n"
            "Usuario: Ya la activé, ¿puedo usarla de inmediato?\n"
            "Asistente: ¡Sí! Ya funciona en comercios físicos y en línea."
        ),
    },
    {
        "conv_id": "CONV-0007", "user_id": "USR-00055", "num_turnos": 3, "cluster_id": 1,
        "texto_completo": (
            "Usuario: Quiero contratar el seguro de auto.\n"
            "Asistente: Cobertura amplia desde $1,200 MXN/mes. ¿Te hago una cotización?\n"
            "Usuario: ¿Cubre daños a terceros?\n"
            "Asistente: Sí, incluye responsabilidad civil, robo total y daños a terceros.\n"
            "Usuario: ¿Cómo lo contrato?\nAsistente: App → Seguros → Auto → Cotizar. 5 minutos y tienes tu póliza."
        ),
    },
    {
        "conv_id": "CONV-0008", "user_id": "USR-00099", "num_turnos": 2, "cluster_id": 4,
        "texto_completo": (
            "Usuario: ¿Cuánto tengo en mi fondo de inversión?\n"
            "Asistente: $87,450 MXN invertidos con rendimiento acumulado de $4,230.50 MXN.\n"
            "Usuario: ¿Puedo agregar más dinero?\n"
            "Asistente: Sí, sin límite mínimo. Ve a Inversiones → Abonar al Fondo Hey."
        ),
    },
    {
        "conv_id": "CONV-0009", "user_id": "USR-00015", "num_turnos": 2, "cluster_id": 0,
        "texto_completo": (
            "Usuario: ¿Qué es el cashback y cómo lo uso?\n"
            "Asistente: Reembolso de hasta 3% en compras seleccionadas. Se abona a tu saldo como dinero disponible.\n"
            "Usuario: ¿En qué categorías aplica?\n"
            "Asistente: Restaurantes, gasolina, supermercados y suscripciones digitales."
        ),
    },
    {
        "conv_id": "CONV-0010", "user_id": "USR-00020", "num_turnos": 4, "cluster_id": 2,
        "texto_completo": (
            "Usuario: No puedo entrar a la app, me dice contraseña incorrecta.\n"
            "Asistente: Toca '¿Olvidaste tu contraseña?' en la pantalla de inicio.\n"
            "Usuario: Ya lo hice pero no me llega el SMS.\n"
            "Asistente: ¿Tienes acceso al correo registrado?\n"
            "Usuario: Sí.\n"
            "Asistente: Usa 'Recuperar por email' para recibir el enlace de restablecimiento."
        ),
    },
]


def seed_mock_data() -> None:
    """Inserta conversaciones mock en ChromaDB si la colección está vacía."""
    from services.chroma_service import collection_count, insert_batch
    from services.embedding_service import get_embeddings_batch

    if collection_count() > 0:
        logger.info(f"ChromaDB ya tiene datos ({collection_count()} docs) — saltando seed.")
        return

    logger.info("Generando embeddings para datos mock...")
    textos  = [c["texto_completo"] for c in MOCK_CONVERSATIONS]
    vectors = get_embeddings_batch(textos)

    records = [
        {
            "conv_id":        conv["conv_id"],
            "vector":         vector,
            "texto_completo": conv["texto_completo"],
            "user_id":        conv["user_id"],
            "num_turnos":     conv["num_turnos"],
            "cluster_id":     conv["cluster_id"],
        }
        for conv, vector in zip(MOCK_CONVERSATIONS, vectors)
    ]

    insert_batch(records)
    logger.info(f"{len(records)} conversaciones mock insertadas en ChromaDB.")

"""
indexar_csv.py
Indexa maestro_conversaciones.csv en ChromaDB.
 
Uso:
    python indexar_csv.py                        # indexa todo
    python indexar_csv.py --limit 5000           # solo las primeras 5000 filas (rápido para probar)
    python indexar_csv.py --reset                # borra la colección y reindexea
    python indexar_csv.py --limit 1000 --reset   # reset + 1000 filas
"""
 
import argparse
import logging
import os
import sys
 
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)
 
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv",   default="maestro_conversaciones.csv")
    parser.add_argument("--limit", type=int, default=None, help="Máx filas a indexar (None = todo)")
    parser.add_argument("--batch", type=int, default=500)
    parser.add_argument("--reset", action="store_true", help="Borrar colección antes de indexar")
    args = parser.parse_args()
 
    from dotenv import load_dotenv
    load_dotenv()
 
    import pandas as pd
    from services.embedding_service import get_embeddings_batch
    from services.chroma_service import _get_collection, insert_batch, collection_count
 
    if args.reset:
        import chromadb
        client = chromadb.PersistentClient(path=os.getenv("CHROMA_PATH", "./chroma_data"))
        try:
            client.delete_collection(os.getenv("COLLECTION_NAME", "hey_conversaciones"))
            logger.info("Colección borrada.")
        except Exception:
            pass
 
    logger.info(f"Leyendo {args.csv}...")
    df = pd.read_csv(args.csv)
 
    # Normalizar columna cluster — puede llamarse 'cluster' o 'cluster_id'
    if "cluster" in df.columns and "cluster_id" not in df.columns:
        df = df.rename(columns={"cluster": "cluster_id"})
 
    df = df.dropna(subset=["conv_id", "texto_completo", "user_id"])
    df["cluster_id"] = df["cluster_id"].fillna(-1).astype(int)
    df["num_turnos"] = df.get("num_turnos", 1).fillna(1).astype(int)
 
    if args.limit:
        df = df.iloc[:args.limit]
        logger.info(f"Limitado a {args.limit} filas.")
 
    logger.info(f"Total a indexar: {len(df)} conversaciones")
 
    total = 0
    for start in range(0, len(df), args.batch):
        chunk = df.iloc[start:start + args.batch]
        textos = chunk["texto_completo"].tolist()
 
        logger.info(f"Generando embeddings lote {start // args.batch + 1} ({len(textos)} docs)...")
        vectors = get_embeddings_batch(textos)
 
        records = [
            {
                "conv_id":        str(row["conv_id"]),
                "vector":         vectors[i],
                "texto_completo": str(row["texto_completo"]),
                "user_id":        str(row["user_id"]),
                "num_turnos":     int(row["num_turnos"]),
                "cluster_id":     int(row["cluster_id"]),
            }
            for i, (_, row) in enumerate(chunk.iterrows())
        ]
 
        insert_batch(records)
        total += len(records)
        logger.info(f"  → Acumulado: {total} / {len(df)}")
 
    logger.info(f"\n✅ Indexación completa: {total} conversaciones")
    logger.info(f"   Total en ChromaDB: {collection_count()}")
 
 
if __name__ == "__main__":
    main()
 
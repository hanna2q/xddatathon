"""
routes/chat.py
Blueprint Flask — POST /api/chat

Flujo RAG adaptativo:
  1. Recibir { user_id, message }
  2. Generar embedding del mensaje
  3. Buscar cluster del usuario en ChromaDB
  4. Buscar conversaciones similares en ChromaDB
  5. Construir prompt dinámico
  6. Llamar al LLM (OpenAI o mock)
  7. Devolver { response }

Todo el flujo es tolerante a fallos: si embeddings o ChromaDB no están
disponibles, el chatbot responde igual usando solo el LLM.
"""

import logging
from flask import Blueprint, request, jsonify

from services.embedding_service import get_embedding
from services.chroma_service    import search_similar, get_user_cluster, collection_count
from services.prompt_builder    import build_prompt
from services.llm_service       import generate_response

logger = logging.getLogger(__name__)

chat_bp = Blueprint("chat", __name__)

# Historial de sesión en memoria (por user_id) — máximo 20 mensajes por usuario
_session_history: dict[str, list[dict]] = {}


@chat_bp.route("/chat", methods=["POST"])
def chat():
    """
    POST /api/chat
    Body:     { "user_id": "USR-00042", "message": "¿Cómo diferio mi tarjeta?" }
    Response: { "response": "...", "cluster_id": 1, "hits": 3, "rag_active": true }
    """
    data = request.get_json(silent=True)

    if not data:
        return jsonify({"error": "Body JSON requerido"}), 400

    user_id = str(data.get("user_id", "")).strip()
    message = str(data.get("message", "")).strip()

    if not user_id:
        return jsonify({"error": "El campo 'user_id' es obligatorio"}), 400
    if not message:
        return jsonify({"error": "El campo 'message' no puede estar vacío"}), 400
    if len(message) > 2000:
        return jsonify({"error": "Mensaje demasiado largo (máx. 2000 caracteres)"}), 400

    logger.info(f"[/chat] user_id={user_id} | msg='{message[:60]}...'")

    try:
        # ── Paso 1: Embedding ─────────────────────────────────────────────────
        query_vector = None
        try:
            query_vector = get_embedding(message)
        except Exception as e:
            logger.warning(f"Embedding falló — continuando sin RAG: {e}")

        # ── Paso 2: Cluster del usuario ───────────────────────────────────────
        cluster_id = None
        if query_vector:
            try:
                cluster_id = get_user_cluster(user_id)
            except Exception as e:
                logger.warning(f"get_user_cluster falló: {e}")

        # ── Paso 3: Búsqueda semántica en ChromaDB ────────────────────────────
        context_hits = []
        rag_active   = False

        if query_vector and collection_count() > 0:
            try:
                # Intento 1: usuario específico + su cluster
                context_hits = search_similar(
                    query_vector=query_vector,
                    top_k=3,
                    user_id=user_id,
                    cluster_id=cluster_id,
                )
                # Intento 2: solo cluster (otros usuarios del mismo segmento)
                if not context_hits and cluster_id is not None:
                    context_hits = search_similar(
                        query_vector=query_vector,
                        top_k=3,
                        cluster_id=cluster_id,
                    )
                # Intento 3: búsqueda libre sin filtros
                if not context_hits:
                    context_hits = search_similar(
                        query_vector=query_vector,
                        top_k=3,
                    )
                rag_active = len(context_hits) > 0
            except Exception as e:
                logger.warning(f"Búsqueda ChromaDB falló: {e}")

        logger.info(f"RAG: {'✅' if rag_active else '⚠️  sin contexto'} | hits={len(context_hits)}")

        # ── Paso 4: Historial de sesión ───────────────────────────────────────
        history = _session_history.get(user_id, [])

        # ── Paso 5: Prompt dinámico ───────────────────────────────────────────
        prompt = build_prompt(
            user_message=message,
            user_id=user_id,
            cluster_id=cluster_id,
            context_hits=context_hits,
            session_history=history,
        )

        # ── Paso 6: LLM ───────────────────────────────────────────────────────
        response_text = generate_response(prompt)

        # ── Paso 7: Actualizar historial ──────────────────────────────────────
        _session_history.setdefault(user_id, [])
        _session_history[user_id].append({"role": "user",      "content": message})
        _session_history[user_id].append({"role": "assistant",  "content": response_text})
        _session_history[user_id] = _session_history[user_id][-20:]

        return jsonify({
            "response":   response_text,
            "cluster_id": cluster_id,
            "hits":       len(context_hits),
            "rag_active": rag_active,
        })

    except Exception as exc:
        logger.exception(f"Error inesperado en /chat: {exc}")
        return jsonify({"error": "Error interno. Intenta de nuevo."}), 500


@chat_bp.route("/chat/history/<user_id>", methods=["DELETE"])
def clear_history(user_id: str):
    _session_history.pop(user_id, None)
    return jsonify({"message": f"Historial de {user_id} limpiado"}), 200


@chat_bp.route("/status", methods=["GET"])
def status():
    """Endpoint de diagnóstico — muestra el estado del sistema."""
    chroma_docs = 0
    try:
        chroma_docs = collection_count()
    except Exception:
        pass

    return jsonify({
        "chroma_docs": chroma_docs,
        "rag_ready":   chroma_docs > 0,
        "llm_provider": __import__("os").getenv("LLM_PROVIDER", "mock"),
    })

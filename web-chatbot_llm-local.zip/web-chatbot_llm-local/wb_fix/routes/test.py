"""
test.py - Prueba directa de Ollama, independiente de Flask.

Corre desde la carpeta web-chatbot:
    python routes/test.py
"""
import sys, os, urllib.request, urllib.error, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dotenv import load_dotenv
load_dotenv()

OLLAMA_URL   = os.getenv("OLLAMA_URL",   "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
PROVIDER     = os.getenv("LLM_PROVIDER", "mock")

print("=" * 50)
print("TEST DE OLLAMA - Hey Banco Chatbot")
print("=" * 50)
print(f"LLM_PROVIDER = {PROVIDER}")
print(f"OLLAMA_URL   = {OLLAMA_URL}")
print(f"OLLAMA_MODEL = {OLLAMA_MODEL}")

print("
[1] Verificando que Ollama esta corriendo...")
try:
    with urllib.request.urlopen(f"{OLLAMA_URL}/api/tags", timeout=5) as r:
        data = json.loads(r.read())
        models = [m["name"] for m in data.get("models", [])]
        print(f"    OK - Modelos disponibles: {models}")
except Exception as e:
    print(f"    ERROR: {e}")
    print("    Ollama no esta corriendo. Abre una terminal y corre: ollama serve")
    sys.exit(1)

print(f"
[2] Probando respuesta de {OLLAMA_MODEL}...")
body = json.dumps({"model": OLLAMA_MODEL, "prompt": "Hola, presentate en una frase corta en espanol.",
    "stream": False, "system": "Eres Havi, asistente de Hey Banco.",
    "options": {"temperature": 0.4, "num_predict": 80}}).encode()
try:
    req = urllib.request.Request(f"{OLLAMA_URL}/api/generate",
        data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        resp = json.loads(r.read())
        print(f"    RESPUESTA: {resp.get('response','').strip()}")
        print("
Todo funciona. Ahora corre: python app.py")
except Exception as e:
    print(f"    ERROR: {e}")
    sys.exit(1)

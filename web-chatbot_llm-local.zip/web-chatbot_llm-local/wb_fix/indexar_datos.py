"""
indexar_datos.py
Script para cargar conversaciones con clusters a ChromaDB.

Acepta el CSV que produce miluvus.ipynb (o consultas_chroma.py si se exporta
con convs_doc.to_csv()):

    Columnas requeridas: conv_id, user_id, texto_completo, num_turnos, cluster_id

    Si tu CSV tiene 'cluster' en lugar de 'cluster_id' (salida directa de
    miluvus.ipynb), renombra la columna antes de ejecutar:
        df = pd.read_csv('mi_csv.csv')
        df = df.rename(columns={'cluster': 'cluster_id'})
        df.to_csv('mi_csv_fixed.csv', index=False)

COMO SE CORRE:
    cd hey_chatbot_chromabd/
    python indexar_datos.py --csv ruta/al/archivo.csv
    python indexar_datos.py --csv ruta/al/archivo.csv --reset   # borra coleccion primero
"""

import argparse
import logging
import sys
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Indexar conversaciones Hey Banco en ChromaDB")
    parser.add_argument("--csv",   required=True,       help="Ruta al CSV con conversaciones y clusters")
    parser.add_argument("--reset", action="store_true", help="Borrar coleccion existente antes de indexar")
    parser.add_argument("--batch", type=int, default=200, help="Tamano de lote (default: 200)")
    args = parser.parse_args()

    from dotenv import load_dotenv
    load_dotenv()

    from services.chroma_service    import _get_collection, insert_batch, collection_count
    from services.embedding_service import get_embeddings_batch

    if args.reset:
        import chromadb, os
        client   = chromadb.PersistentClient(path=os.getenv("CHROMA_PATH", "./chroma_data"))
        col_name = os.getenv("COLLECTION_NAME", "hey_conversaciones")
        try:
            client.delete_collection(col_name)
            logger.info(f"Coleccion '{col_name}' eliminada.")
        except Exception:
            pass

    logger.info(f"Cargando CSV: {args.csv}")
    try:
        df = pd.read_csv(args.csv)
    except FileNotFoundError:
        logger.error(f"No se encontro el archivo: {args.csv}")
        sys.exit(1)

    # Compatibilidad: si el CSV viene directo de miluvus.ipynb con columna 'cluster'
    # la renombramos a 'cluster_id' automaticamente.
    if "cluster" in df.columns and "cluster_id" not in df.columns:
        df = df.rename(columns={"cluster": "cluster_id"})
        logger.info("Columna 'cluster' renombrada a 'cluster_id' automaticamente.")

    required = {"conv_id", "user_id", "texto_completo", "num_turnos", "cluster_id"}
    missing  = required - set(df.columns)
    if missing:
        logger.error(f"Al CSV le faltan columnas: {missing}")
        logger.error(f"Columnas encontradas: {list(df.columns)}")
        sys.exit(1)

    df = df.dropna(subset=["texto_completo", "conv_id", "user_id"])
    logger.info(f"Filas validas a indexar: {len(df)}")

    total = 0
    for start in range(0, len(df), args.batch):
        chunk  = df.iloc[start : start + args.batch]
        textos = chunk["texto_completo"].tolist()

        logger.info(f"Generando embeddings para lote {start // args.batch + 1} ({len(textos)} docs)...")
        vectors = get_embeddings_batch(textos)

        records = [
            {
                "conv_id":        str(row["conv_id"]),
                "vector":         vectors[i],
                "texto_completo": str(row["texto_completo"]),
                "user_id":        str(row["user_id"]),
                "num_turnos":     int(row.get("num_turnos", 0)),
                "cluster_id":     int(row.get("cluster_id", -1)),
            }
            for i, (_, row) in enumerate(chunk.iterrows())
        ]

        insert_batch(records)
        total += len(records)
        logger.info(f"Lote insertado. Total acumulado: {total}")

    logger.info(f"\nIndexacion completa: {total} conversaciones en ChromaDB")
    logger.info(f"   Total en coleccion: {collection_count()}")


if __name__ == "__main__":
    main()

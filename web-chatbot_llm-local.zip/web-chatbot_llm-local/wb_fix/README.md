# Hey Banco Chatbot — MVP RAG + ChromaDB

## Flujo de ejecución completo

### Paso 0 — Instalar dependencias (solo una vez)
```powershell
python -m pip install -r requirements.txt
python -m pip install google-genai
```

### Paso 1 — Verificar que Gemini funciona (antes de correr la app)
```powershell
python routes/test.py
```
Imprime exactamente si la API key es válida y si Gemini responde.
Si falla, el mensaje explica la causa y cómo resolverla.

### Paso 2 — Indexar datos (solo cuando cambie el dataset)

**Opción A — tienes el dataset crudo (dataset_50k_anonymized.csv):**
```powershell
python services/consultas_chroma.py
```
Hace todo: carga CSV → genera embeddings → entrena KMeans → indexa en ChromaDB.
Tarda varios minutos. Guarda el CSV maestro en data/processed/maestro_conversaciones.csv.

**Opción B — tienes el CSV maestro ya procesado:**
```powershell
python indexar.py --csv data/processed/maestro_conversaciones.csv
```
Solo re-indexa, sin recalcular embeddings ni clusters. Más rápido.

### Paso 3 — Levantar la app
```powershell
python app.py
```

### Paso 4 — Abrir en el navegador
```
http://127.0.0.1:5000
```

---

## Diferencia entre los scripts de indexación

| Script | Cuándo usar |
|--------|-------------|
| `python services/consultas_chroma.py` | Dataset crudo nuevo. Recalcula embeddings y clusters KMeans desde cero. |
| `python indexar.py --csv archivo.csv` | Ya tienes el CSV con cluster_id. Solo sube a ChromaDB, sin recalcular nada. |
| `python indexar_datos.py --csv archivo.csv` | Igual que indexar.py pero requiere pasar --csv obligatorio. |

**Para el datathon: usa siempre `consultas_chroma.py` la primera vez.**

---

## Por qué se agota la quota de Gemini rápido

El prompt que se envía a Gemini incluye:
- Perfil del cluster del usuario
- Features financieras
- Contexto RAG (conversaciones completas de ChromaDB)
- Historial de sesión

Eso puede pesar 3,000–8,000 tokens por request. El free tier de Gemini
limita por tokens por minuto, no solo por número de llamadas.
Con 20 consultas largas puedes agotar el límite.

Solución: genera una nueva API key en https://aistudio.google.com/apikey

---

## Error 403 en la API key

Tu key tiene restricciones de dominio/IP. Para resolverlo:
1. Ve a https://console.cloud.google.com
2. APIs & Services → Credenciales → tu API key
3. Restricciones de aplicación → selecciona **Ninguna**
4. Guarda y espera 1-2 minutos

"""
prompt_builder.py
Construye el prompt dinamico (RAG adaptativo) para el LLM.

Integra:
  - Perfil del usuario: cluster_id, features financieras
  - Contexto semantico recuperado desde ChromaDB
  - Historial reciente de la sesion actual

Basado en la estructura de datos del dataset Hey Banco:
  Clientes: ingreso_mensual_mx, score_buro, satisfaccion_1_10,
             es_hey_pro, tiene_seguro, usa_hey_shop, etc.
  Transacciones: categoria_mcc, canal, monto, cashback_generado, etc.
  Conversaciones: texto_completo (Usuario/Asistente turnos)
"""

import logging

logger = logging.getLogger(__name__)

# ── Descripcion de clusters (personalidad financiera) ─────────────────────────
# Perfiles derivados del analisis KMeans sobre embeddings de conversaciones.
# Actualiza estos perfiles con los arquetipos reales que observes en tus datos
# despues de correr consultas_chroma.py con el dataset completo.
CLUSTER_PROFILES: dict[int, dict] = {
    0: {
        "nombre":      "Ahorrador Cauteloso",
        "descripcion": (
            "Cliente con bajo uso de credito, alta antiguedad, prefiere canales digitales. "
            "Valora la seguridad y la transparencia. Raramente usa productos premium."
        ),
        "tono": "formal y tranquilizador",
    },
    1: {
        "nombre":      "Usuario Premium Activo",
        "descripcion": (
            "Cliente Hey Pro con alto ingreso mensual, score de buro elevado y seguro contratado. "
            "Usa Hey Shop, prefiere respuestas rapidas y soluciones directas. "
            "Alta frecuencia transaccional en categorias de restaurantes y viajes."
        ),
        "tono": "ejecutivo y conciso",
    },
    2: {
        "nombre":      "Nuevo Digital",
        "descripcion": (
            "Usuario joven con poca antiguedad, apertura via app, transacciones pequenas frecuentes. "
            "Muy activo en e-commerce. Puede tener dudas sobre productos basicos."
        ),
        "tono": "amigable y didactico",
    },
    3: {
        "nombre":      "Receptor de Remesas",
        "descripcion": (
            "Cliente que recibe remesas internacionales de forma recurrente. "
            "Sensible al tipo de cambio. Prefiere operaciones en efectivo y transferencias."
        ),
        "tono": "cercano y en lenguaje simple",
    },
    4: {
        "nombre":      "Inversor Moderado",
        "descripcion": (
            "Cliente con saldo elevado, baja utilizacion de credito, interesado en rendimientos. "
            "Solicita informacion sobre CETES, fondos y plazos fijos."
        ),
        "tono": "profesional y orientado a datos",
    },
    **{
        k: {
            "nombre":      f"Perfil General {k}",
            "descripcion": "Cliente con comportamiento mixto. Se adapta segun el contexto de la consulta.",
            "tono":        "neutro y servicial",
        }
        for k in range(5, 10)
    },
}

DEFAULT_CLUSTER = {
    "nombre":      "Cliente General",
    "descripcion": "No se identifico un perfil especifico. Se responde de forma generica.",
    "tono":        "neutro y servicial",
}


def _format_context_hits(hits: list[dict], max_chars_per_hit: int = 500) -> str:
    """Formatea los resultados de ChromaDB en texto legible para el prompt."""
    if not hits:
        return "No se encontro historial relevante para esta consulta."

    lines = []
    for i, h in enumerate(hits, 1):
        preview = h.get("texto_completo", "")[:max_chars_per_hit]
        score   = h.get("score", 0)
        lines.append(
            f"[Conversacion {i} | similitud={score:.2f} | turnos={h.get('num_turnos', '?')}]\n"
            f"{preview}{'...' if len(h.get('texto_completo', '')) > max_chars_per_hit else ''}"
        )
    return "\n\n".join(lines)


def build_prompt(
    user_message:    str,
    user_id:         str,
    cluster_id:      int | None,
    context_hits:    list[dict],
    session_history: list[dict] | None = None,
    user_features:   dict | None = None,
) -> str:
    """
    Construye el prompt completo para el LLM.

    Args:
        user_message:    Mensaje actual del usuario.
        user_id:         ID del usuario (ej. "USR-00042").
        cluster_id:      Cluster KMeans del usuario (0-9). None = sin perfil.
        context_hits:    Resultados de busqueda semantica en ChromaDB.
        session_history: Historial de la sesion actual [{role, content}, ...].
        user_features:   Features financieras del usuario (del dataset de clientes).

    Returns:
        String con el prompt completo listo para enviar al LLM.
    """
    # 1. Perfil de cluster
    profile = CLUSTER_PROFILES.get(cluster_id, DEFAULT_CLUSTER) if cluster_id is not None else DEFAULT_CLUSTER

    # 2. Features del usuario
    if not user_features:
        user_features = _mock_user_features(user_id)
    features_text = _format_user_features(user_features)

    # 3. Contexto recuperado de ChromaDB
    context_text = _format_context_hits(context_hits)

    # 4. Historial de sesion actual (ultimas 6 interacciones)
    history_text = ""
    if session_history:
        turns = []
        for entry in session_history[-6:]:
            role = "Usuario" if entry["role"] == "user" else "Asistente"
            turns.append(f"{role}: {entry['content']}")
        history_text = "\n".join(turns)

    # 5. Prompt ensamblado
    prompt = f"""Eres un asistente financiero virtual de Hey Banco, especializado y empatico.
Tu tono debe ser: {profile['tono']}.

═══════════════════════════════════════════
PERFIL DEL USUARIO
═══════════════════════════════════════════
ID: {user_id}
Segmento: {profile['nombre']}
Comportamiento: {profile['descripcion']}

FEATURES FINANCIERAS RELEVANTES:
{features_text}

═══════════════════════════════════════════
HISTORIAL SEMANTICO RECUPERADO (RAG)
═══════════════════════════════════════════
Las siguientes son conversaciones previas similares recuperadas de ChromaDB:

{context_text}

═══════════════════════════════════════════
CONVERSACION ACTUAL
═══════════════════════════════════════════
{history_text}
Usuario: {user_message}
Asistente:"""

    logger.debug(f"Prompt construido ({len(prompt)} chars) para user_id={user_id} cluster={cluster_id}")
    return prompt


def _mock_user_features(user_id: str) -> dict:
    """
    Features mock basadas en el dataset hey_clientes.
    En produccion consultar la base de datos real con el user_id.
    """
    seed = sum(ord(c) for c in user_id) % 100
    return {
        "ingreso_mensual_mx":   round(8000 + seed * 420, 2),
        "score_buro":           seed * 6 + 450,
        "satisfaccion_1_10":    round(5 + (seed % 5) + 0.5, 1),
        "es_hey_pro":           seed > 60,
        "nomina_domiciliada":   seed > 40,
        "recibe_remesas":       seed < 20,
        "usa_hey_shop":         seed > 50,
        "tiene_seguro":         seed > 70,
        "nivel_educativo":      ["Secundaria", "Preparatoria", "Universidad", "Postgrado"][seed % 4],
        "antiguedad_dias":      seed * 30 + 90,
        "num_productos":        (seed % 4) + 1,
        "saldo_total":          round(seed * 1500.0, 2),
        "utilizacion_promedio": round((seed % 80) / 100, 2),
        "ratio_deuda_promedio": round((seed % 60) / 100, 2),
        "tasa_aprobacion":      round(0.75 + (seed % 25) / 100, 2),
        "cashback_total":       round(seed * 12.5, 2),
        "es_internacional_pct": round((seed % 30) / 100, 2),
    }


def _format_user_features(features: dict) -> str:
    """Formatea las features en texto legible para el prompt."""
    labels = {
        "ingreso_mensual_mx":   "Ingreso mensual (MXN)",
        "score_buro":           "Score Buro",
        "satisfaccion_1_10":    "Satisfaccion (1-10)",
        "es_hey_pro":           "Hey Pro",
        "nomina_domiciliada":   "Nomina domiciliada",
        "recibe_remesas":       "Recibe remesas",
        "usa_hey_shop":         "Usa Hey Shop",
        "tiene_seguro":         "Tiene seguro",
        "nivel_educativo":      "Nivel educativo",
        "antiguedad_dias":      "Antiguedad (dias)",
        "num_productos":        "Numero de productos",
        "saldo_total":          "Saldo total (MXN)",
        "utilizacion_promedio": "Utilizacion promedio credito",
        "ratio_deuda_promedio": "Ratio de deuda promedio",
        "tasa_aprobacion":      "Tasa de aprobacion transacciones",
        "cashback_total":       "Cashback acumulado (MXN)",
        "es_internacional_pct": "% transacciones internacionales",
    }

    lines = []
    for key, label in labels.items():
        val = features.get(key)
        if val is None:
            continue
        if isinstance(val, bool):
            val = "Si" if val else "No"
        elif isinstance(val, float) and 0 < val < 1:
            val = f"{val * 100:.1f}%"
        lines.append(f"  - {label}: {val}")

    return "\n".join(lines)

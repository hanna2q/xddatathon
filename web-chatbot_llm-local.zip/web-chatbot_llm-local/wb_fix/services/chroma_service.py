"""
chroma_service.py
Reemplaza completamente a milvus_service.py.

ChromaDB guarda todo en una carpeta local (CHROMA_PATH).
No requiere servidor externo, no requiere definir esquemas de antemano.

Esquema de cada documento en la colección:
  - id              (str)  — identificador único, ej. "CONV-0001"
  - embedding       (list[float]) — vector 384-dim normalizado
  - document        (str)  — texto de la conversación reconstruida
  - metadata:
      - user_id     (str)  — ej. "USR-00042"
      - cluster_id  (int)  — cluster KMeans (-1 si aún no se tienen clusters)
      - num_turnos  (int)  — número de turnos
      - conv_id     (str)  — ID de conversación original

Diferencias clave vs Milvus:
  - Sin definición de esquema previa
  - Metadata es un dict simple de Python
  - La búsqueda devuelve resultados ordenados por similitud coseno automáticamente
  - Los filtros usan sintaxis de dict: where={"user_id": "USR-00042"}
  - Soporta múltiples filtros con $and
"""

import logging
import os
import chromadb
from chromadb.config import Settings

logger = logging.getLogger(__name__)

CHROMA_PATH     = os.getenv("CHROMA_PATH", "./chroma_data")
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "hey_conversaciones")

# Cliente singleton
_client: chromadb.ClientAPI | None = None
_collection = None


def _get_collection():
    """
    Retorna (y crea si no existe) la colección ChromaDB.
    ChromaDB usa similitud coseno por defecto con embeddings normalizados.
    """
    global _client, _collection
    if _collection is None:
        logger.info(f"Conectando a ChromaDB en: {CHROMA_PATH}")
        _client = chromadb.PersistentClient(
            path=CHROMA_PATH,
            settings=Settings(anonymized_telemetry=False),  # sin telemetría
        )
        _collection = _client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},  # métrica coseno = igual que el script original
        )
        logger.info(f"Colección '{COLLECTION_NAME}' lista ({_collection.count()} docs)")
    return _collection


# ── Inserción ─────────────────────────────────────────────────────────────────

def insert_conversation(
    conv_id: str,
    vector: list[float],
    texto_completo: str,
    user_id: str,
    num_turnos: int,
    cluster_id: int = -1,
) -> None:
    """
    Inserta una conversación en ChromaDB.

    Args:
        conv_id:         ID único (ej. "CONV-0001"). ChromaDB lo usa como PK.
        vector:          Embedding normalizado 384-dim.
        texto_completo:  Texto reconstruido de la conversación.
        user_id:         ID del usuario.
        num_turnos:      Número de turnos.
        cluster_id:      Cluster KMeans. Usa -1 si aún no tienes clusters.
    """
    col = _get_collection()
    col.upsert(  # upsert: inserta o actualiza si ya existe el ID
        ids=[conv_id],
        embeddings=[vector],
        documents=[texto_completo],
        metadatas=[{
            "user_id":    user_id,
            "cluster_id": cluster_id,
            "num_turnos": num_turnos,
            "conv_id":    conv_id,
        }],
    )
    logger.debug(f"Insertado: {conv_id} | user={user_id} | cluster={cluster_id}")


def insert_batch(records: list[dict]) -> None:
    """
    Inserta múltiples conversaciones en un solo llamado (ChromaDB es eficiente en batch).

    Cada record debe tener:
        conv_id, vector, texto_completo, user_id, num_turnos, cluster_id (opcional)

    Ejemplo de uso al integrar el CSV de miluvus/consultas_chroma:
        records = [
            {
                "conv_id":        row["conv_id"],
                "vector":         embedding_list,
                "texto_completo": row["texto_completo"],
                "user_id":        row["user_id"],
                "num_turnos":     int(row["num_turnos"]),
                "cluster_id":     int(row["cluster_id"]),  # columna 'cluster_id' en el DataFrame
            }
            for row in df.iterrows()
        ]
        insert_batch(records)
    """
    col = _get_collection()
    col.upsert(
        ids=          [r["conv_id"]        for r in records],
        embeddings=   [r["vector"]         for r in records],
        documents=    [r["texto_completo"] for r in records],
        metadatas=    [{
            "user_id":    r["user_id"],
            "cluster_id": r.get("cluster_id", -1),
            "num_turnos": r.get("num_turnos", 0),
            "conv_id":    r["conv_id"],
        } for r in records],
    )
    logger.info(f"✅ Batch insertado: {len(records)} conversaciones")


# ── Búsqueda semántica ────────────────────────────────────────────────────────

def search_similar(
    query_vector: list[float],
    top_k: int = 3,
    user_id: str | None = None,
    cluster_id: int | None = None,
    min_turnos: int | None = None,
) -> list[dict]:
    """
    Busca las conversaciones más similares al vector de consulta.

    Los filtros de ChromaDB usan sintaxis de dict con operadores:
      - Igualdad simple: {"user_id": "USR-00042"}
      - Múltiples filtros: {"$and": [{"user_id": "USR-00042"}, {"cluster_id": 1}]}
      - Comparación: {"num_turnos": {"$gte": 2}}

    Args:
        query_vector: Embedding 384-dim normalizado.
        top_k:        Resultados máximos.
        user_id:      Filtrar por usuario.
        cluster_id:   Filtrar por cluster.
        min_turnos:   Mínimo de turnos.

    Returns:
        Lista de dicts con: conv_id, user_id, cluster_id, num_turnos,
                            texto_completo, score (distancia coseno 0-1, menor = más similar)
    """
    col = _get_collection()

    # Si la colección está vacía, retornar lista vacía directamente
    if col.count() == 0:
        logger.warning("ChromaDB vacío — sin contexto RAG disponible")
        return []

    # Construir filtro where
    where = _build_where(user_id=user_id, cluster_id=cluster_id, min_turnos=min_turnos)

    try:
        results = col.query(
            query_embeddings=[query_vector],
            n_results=min(top_k, col.count()),  # no pedir más de lo que hay
            where=where,
            include=["documents", "metadatas", "distances"],
        )
    except Exception as exc:
        logger.warning(f"Error en query ChromaDB (where={where}): {exc}")
        return []

    # Formatear resultados
    hits = []
    ids        = results["ids"][0]
    docs       = results["documents"][0]
    metas      = results["metadatas"][0]
    distances  = results["distances"][0]

    for doc_id, doc, meta, dist in zip(ids, docs, metas, distances):
        hits.append({
            "conv_id":        meta.get("conv_id", doc_id),
            "user_id":        meta.get("user_id", ""),
            "cluster_id":     meta.get("cluster_id", -1),
            "num_turnos":     meta.get("num_turnos", 0),
            "texto_completo": doc,
            "score":          round(dist, 4),  # 0 = idéntico, 1 = opuesto
        })

    logger.debug(f"ChromaDB devolvió {len(hits)} resultados (where={where})")
    return hits


def get_user_cluster(user_id: str) -> int | None:
    """
    Recupera el cluster más frecuente del usuario desde ChromaDB.
    Retorna None si no hay datos o si los clusters aún no están asignados.
    """
    col = _get_collection()
    try:
        results = col.get(
            where={"user_id": user_id},
            include=["metadatas"],
            limit=50,
        )
        if not results or not results["metadatas"]:
            return None
        clusters = [
            m["cluster_id"] for m in results["metadatas"]
            if m.get("cluster_id", -1) != -1  # ignorar los sin cluster
        ]
        if not clusters:
            return None
        return max(set(clusters), key=clusters.count)
    except Exception as exc:
        logger.warning(f"No se pudo obtener cluster de {user_id}: {exc}")
        return None


def collection_count() -> int:
    """Retorna el número de documentos en la colección."""
    try:
        return _get_collection().count()
    except Exception:
        return 0


# ── Helpers internos ──────────────────────────────────────────────────────────

def _build_where(
    user_id: str | None,
    cluster_id: int | None,
    min_turnos: int | None,
) -> dict | None:
    """
    Construye el filtro where de ChromaDB.
    ChromaDB requiere que el filtro tenga al menos una condición.
    Si no hay filtros, retorna None (sin filtro = busca en toda la colección).
    """
    conditions = []

    if user_id:
        conditions.append({"user_id": {"$eq": user_id}})
    if cluster_id is not None and cluster_id != -1:
        conditions.append({"cluster_id": {"$eq": cluster_id}})
    if min_turnos is not None:
        conditions.append({"num_turnos": {"$gte": min_turnos}})

    if not conditions:
        return None
    if len(conditions) == 1:
        return conditions[0]
    return {"$and": conditions}

"""
consultas_chroma.py
Pipeline completo: CSV → embeddings → clusters KMeans → ChromaDB.

Basado en miluvus.ipynb (el notebook que preserva user_id correctamente).
Cada documento = una conversación completa agrupada por conv_id.
El user_id se extrae como metadato del primer registro de cada grupo.

CUÁNDO SE CORRE:
    Una sola vez (o cuando el dataset cambie).
    Genera/actualiza la carpeta chroma_data/ que usa la app Flask.

CÓMO SE CORRE:
    cd hey_chatbot_chromabd/
    python services/consultas_chroma.py

REQUIERE:
    dataset_50k_anonymized.csv en el directorio donde se ejecuta el script.
    Las dependencias de requirements.txt instaladas.
"""

import os
import warnings
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
import chromadb
from chromadb.config import Settings

warnings.filterwarnings("ignore")

EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL",
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
)
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "hey_conversaciones")
CHROMA_PATH     = os.getenv("CHROMA_PATH", "./chroma_data")
CSV_PATH        = os.getenv("CSV_PATH", "dataset_50k_anonymized.csv")
N_CLUSTERS      = 10
BATCH_SIZE      = 500


def rebuild_conversation(group: pd.DataFrame) -> str:
    turns = []
    for _, row in group.iterrows():
        turns.append(f"Usuario: {str(row['input']).strip()}")
        turns.append(f"Asistente: {str(row['output']).strip()}")
    return "\n".join(turns)


def cargar_y_preparar(csv_path: str = CSV_PATH) -> pd.DataFrame:
    """
    Carga el CSV, filtra canal texto y reconstruye conversaciones agrupadas
    por conv_id. El user_id se preserva via groupby+agg, igual que miluvus.ipynb,
    garantizando que cada documento en ChromaDB siempre tenga su user_id.
    """
    df = pd.read_csv(csv_path)
    df = df[df["channel_source"] == 1].copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)
    df = df.sort_values(["conv_id", "date"])

    print(f"Filas tras filtrar canal texto: {len(df)}")
    print(f"Conversaciones unicas:          {df['conv_id'].nunique()}")

    convs_grouped = (
        df.groupby("conv_id", group_keys=False)
        .apply(rebuild_conversation)
        .reset_index()
        .rename(columns={0: "texto_completo"})
    )

    meta = (
        df.groupby("conv_id")
        .agg(
            user_id    = ("user_id", "first"),
            num_turnos = ("input",   "count"),
            fecha      = ("date",    "first"),
        )
        .reset_index()
    )

    convs_doc = convs_grouped.merge(meta, on="conv_id")
    print(f"\nDocumentos a indexar: {len(convs_doc)}")
    print(convs_doc[["conv_id", "user_id", "num_turnos"]].head())
    return convs_doc


def generar_embeddings(convs_doc: pd.DataFrame):
    """Genera embeddings normalizados con el mismo modelo que embedding_service.py"""
    print("\nCargando modelo de embeddings...")
    model = SentenceTransformer(EMBEDDING_MODEL)
    print("Generando embeddings...")
    embeddings = model.encode(
        convs_doc["texto_completo"].tolist(),
        batch_size           = 64,
        show_progress_bar    = True,
        normalize_embeddings = True,
    )
    print(f"Shape embeddings: {embeddings.shape}")
    return embeddings


def asignar_clusters(convs_doc: pd.DataFrame, embeddings) -> tuple:
    """
    Entrena KMeans y asigna cluster a cada conversación.
    Usa la columna 'cluster_id' (no 'cluster') para ser consistente con
    el esquema de metadata de chroma_service.py.
    """
    print(f"\nEntrenando KMeans con {N_CLUSTERS} clusters...")
    kmeans = KMeans(n_clusters=N_CLUSTERS, random_state=42, n_init="auto")
    kmeans.fit(embeddings)

    convs_doc = convs_doc.copy()
    convs_doc["cluster_id"] = kmeans.labels_

    print("Distribucion de clusters:")
    print(convs_doc["cluster_id"].value_counts().sort_index())
    return convs_doc, kmeans


def indexar_en_chroma(convs_doc: pd.DataFrame, embeddings) -> chromadb.Collection:
    """
    Indexa todas las conversaciones en ChromaDB via upsert (seguro re-ejecutar).

    Esquema de metadata (alineado con chroma_service.py):
        conv_id    (str) — ID de conversacion
        user_id    (str) — ID de usuario (siempre presente)
        num_turnos (int) — numero de turnos
        cluster_id (int) — cluster KMeans
        fecha      (str) — fecha primer turno YYYY-MM-DD
    """
    chroma_client = chromadb.PersistentClient(
        path     = CHROMA_PATH,
        settings = Settings(anonymized_telemetry=False),
    )

    collection = chroma_client.get_or_create_collection(
        name     = COLLECTION_NAME,
        metadata = {"hnsw:space": "cosine"},
    )

    print(f"\nColeccion '{COLLECTION_NAME}' — docs previos: {collection.count()}")

    total = 0
    for i in range(0, len(convs_doc), BATCH_SIZE):
        chunk  = convs_doc.iloc[i : i + BATCH_SIZE]
        embeds = embeddings[i : i + BATCH_SIZE]

        collection.upsert(
            ids        = chunk["conv_id"].astype(str).tolist(),
            embeddings = embeds.tolist(),
            documents  = chunk["texto_completo"].tolist(),
            metadatas  = [
                {
                    "conv_id":    str(row["conv_id"]),
                    "user_id":    str(row["user_id"]),
                    "num_turnos": int(row["num_turnos"]),
                    "cluster_id": int(row["cluster_id"]),
                    "fecha":      str(row["fecha"])[:10] if pd.notna(row["fecha"]) else "",
                }
                for _, row in chunk.iterrows()
            ],
        )
        total += len(chunk)
        print(f"  Lote {i // BATCH_SIZE + 1}: {len(chunk)} conversaciones insertadas")

    print(f"\nIndexacion completa — {total} conversaciones en '{COLLECTION_NAME}'")
    print(f"   Total en ChromaDB: {collection.count()}")
    return collection


def buscar(
    query,
    collection,
    model,
    top_k      = 3,
    user_id    = None,
    min_turnos = None,
    cluster_id = None,
) -> list:
    """
    Busqueda semantica con consultas divididas por granularidad.
    Filtra por 'cluster_id' (consistente con el esquema de indexacion).
    """
    q_emb = model.encode([query], normalize_embeddings=True).tolist()

    condiciones = []
    if user_id:
        condiciones.append({"user_id": {"$eq": user_id}})
    if min_turnos is not None:
        condiciones.append({"num_turnos": {"$gte": min_turnos}})
    if cluster_id is not None:
        condiciones.append({"cluster_id": {"$eq": cluster_id}})

    if not condiciones:
        where = None
    elif len(condiciones) == 1:
        where = condiciones[0]
    else:
        where = {"$and": condiciones}

    n = min(top_k, collection.count())
    results = collection.query(
        query_embeddings = q_emb,
        n_results        = n,
        where            = where,
        include          = ["documents", "metadatas", "distances"],
    )

    print(f"\nQuery: '{query}'")
    if where:
        print(f"   Filtro: {where}")
    print("-" * 60)

    hits = []
    for doc_id, doc, meta, dist in zip(
        results["ids"][0],
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        similitud = round(1 - dist, 4)
        hits.append({
            "conv_id":        meta.get("conv_id", doc_id),
            "user_id":        meta.get("user_id", ""),
            "num_turnos":     meta.get("num_turnos", 0),
            "cluster_id":     meta.get("cluster_id", -1),
            "texto_completo": doc,
            "score":          similitud,
        })
        print(f"conv_id={hits[-1]['conv_id']} user={hits[-1]['user_id']} "
              f"cluster={hits[-1]['cluster_id']} sim={similitud}")
        print(doc[:400])
        print("-" * 60)

    return hits


if __name__ == "__main__":
    print("=" * 60)
    print("Pipeline: CSV → Embeddings → KMeans → ChromaDB")
    print("=" * 60)

    convs_doc  = cargar_y_preparar(CSV_PATH)
    embeddings = generar_embeddings(convs_doc)
    convs_doc, kmeans = asignar_clusters(convs_doc, embeddings)
    # === GUARDAR CSV MAESTRO ===
    OUTPUT_PATH = "./data/processed/maestro_conversaciones.csv"

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

    convs_doc.to_csv(OUTPUT_PATH, index=False, encoding="utf-8")

    print(f"\nCSV maestro guardado en: {OUTPUT_PATH}")
    collection = indexar_en_chroma(convs_doc, embeddings)
    

    print("\nListo! Base de datos Chroma en:", CHROMA_PATH)
    print("   Corre la app Flask con: python app.py")

    print("\n" + "=" * 60)
    print("Prueba de consultas divididas:")
    print("=" * 60)
    model_test = SentenceTransformer(EMBEDDING_MODEL)

    print("\n[1] Busqueda libre (sin filtros):")
    buscar("Como puedo diferir una compra?", collection, model_test, top_k=3)

    print("\n[2] Filtrada por cluster:")
    buscar("inversion y rendimientos", collection, model_test, top_k=3, cluster_id=4)

    print("\n[3] Conversaciones largas (mas contexto):")
    buscar("problema con transferencia", collection, model_test, top_k=3, min_turnos=3)

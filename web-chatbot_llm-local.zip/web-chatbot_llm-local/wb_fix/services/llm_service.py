import logging, os, random, urllib.request, urllib.error, json
logger = logging.getLogger(__name__)
OLLAMA_URL   = os.getenv("OLLAMA_URL",   "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
_MOCK = {
    "saludo":        ["Hola! Soy el asistente de Hey Banco. En que puedo ayudarte?"],
    "saldo":         ["Tu saldo disponible es de $12,450.00 MXN."],
    "transferencia": ["Para transferir ve a Mover dinero en la app."],
    "credito":       ["Tu limite es $30,000 MXN con 42% de utilizacion."],
    "diferir":       ["Para diferir: Tarjetas, selecciona el cargo, Diferir. 3, 6, 9 o 12 meses."],
    "remesas":       ["Las remesas se acreditan en maximo 2 dias habiles."],
    "inversion":     ["Fondo Hey al 11.5% TIIE anual, CETES desde $100 MXN."],
    "seguro":        ["Seguros de vida, gastos medicos y auto disponibles."],
    "cashback":      ["Hasta 3% en restaurantes, gasolina y supermercados."],
    "problema":      ["Lamento el inconveniente. Dame la fecha y monto del cargo."],
    "default":       ["Puedo ayudarte con saldos, tarjetas, inversiones y mas."],
}
_KW = {
    "saludo":["hola","buenas","buenos","hey","saludos"],
    "saldo":["saldo","disponible","balance","dinero"],
    "transferencia":["transferencia","transferir","enviar","spei","clabe"],
    "credito":["tarjeta","credito","limite","corte"],
    "diferir":["diferir","meses","mensualidad","plazos"],
    "remesas":["remesa","dolar","internacional"],
    "inversion":["invers","rendimiento","cetes","fondo","ahorr"],
    "seguro":["seguro","protege","cobertura"],
    "cashback":["cashback","reembolso","puntos"],
    "problema":["problema","error","fallo","urgente","queja"],
}
def _classify(t):
    l=t.lower()
    for c,kws in _KW.items():
        if any(k in l for k in kws): return c
    return "default"
def _mock(p):
    c=_classify(p); logger.info(f"[MOCK] cat={c}")
    return random.choice(_MOCK.get(c,_MOCK["default"]))
def _ollama(prompt):
    url=f"{OLLAMA_URL}/api/generate"
    logger.info(f"[OLLAMA] -> {OLLAMA_MODEL}")
    body=json.dumps({"model":OLLAMA_MODEL,"prompt":prompt,"stream":False,
        "system":"Eres Havi, asistente financiero de Hey Banco. Responde SIEMPRE en espanol, maximo 4 oraciones, de forma empatica y concisa.",
        "options":{"temperature":0.5,"num_predict":300}}).encode()
    try:
        req=urllib.request.Request(url,data=body,headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=120) as r:
            d=json.loads(r.read()); t=d.get("response","").strip()
            logger.info(f"[OLLAMA] OK ({len(t)} chars)"); return t
    except urllib.error.URLError as e:
        logger.error(f"[OLLAMA] Sin conexion: {e}")
        logger.warning("[OLLAMA] Corre en otra terminal: ollama serve")
        return _mock(prompt)
    except Exception as e:
        logger.error(f"[OLLAMA] Error: {e}"); return _mock(prompt)
def generate_response(prompt):
    p=os.getenv("LLM_PROVIDER","mock").strip().lower()
    logger.info(f"[LLM] provider={p}")
    if p=="ollama": return _ollama(prompt)
    return _mock(prompt)

"""
embedding_service.py
Genera embeddings usando el mismo modelo que se usó para indexar
las conversaciones en Milvus: paraphrase-multilingual-MiniLM-L12-v2

Dimensión: 384 vectores normalizados (normalize_embeddings=True)
"""

import logging
import os
from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)

# Cargamos el modelo UNA vez al importar el módulo (costoso en RAM/tiempo)
_MODEL_NAME = os.getenv("EMBEDDING_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
_model: SentenceTransformer | None = None


def _get_model() -> SentenceTransformer:
    """Carga (lazy) el modelo de embeddings."""
    global _model
    if _model is None:
        logger.info(f"Cargando modelo de embeddings: {_MODEL_NAME}")
        _model = SentenceTransformer(_MODEL_NAME)
        logger.info("Modelo cargado correctamente.")
    return _model


def get_embedding(text: str) -> list[float]:
    """
    Genera el embedding normalizado de un texto.

    Args:
        text: Texto a convertir en vector.

    Returns:
        Lista de floats con dimensión 384 (normalizada).
    """
    model = _get_model()
    vector = model.encode(
        [text],
        normalize_embeddings=True,  # igual que en el script original
        show_progress_bar=False,
    )
    return vector[0].tolist()


def get_embeddings_batch(texts: list[str]) -> list[list[float]]:
    """
    Genera embeddings para una lista de textos (procesamiento en lote).

    Args:
        texts: Lista de strings.

    Returns:
        Lista de vectores (cada uno es list[float]).
    """
    model = _get_model()
    vectors = model.encode(
        texts,
        batch_size=64,
        normalize_embeddings=True,
        show_progress_bar=False,
    )
    return [v.tolist() for v in vectors]

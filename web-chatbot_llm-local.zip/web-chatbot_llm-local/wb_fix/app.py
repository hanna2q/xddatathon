"""
app.py — Entrypoint del MVP Chatbot Hey Banco
"""

import logging
import os
from flask import Flask, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Inicializar ChromaDB
try:
    from services.chroma_service import _get_collection
    _get_collection()
    logger.info("ChromaDB listo")
    try:
        from mock_data import seed_mock_data
        seed_mock_data()
    except Exception as seed_err:
        logger.warning(f"Seed mock falló (no crítico): {seed_err}")
except Exception as chroma_err:
    logger.warning(f"ChromaDB no disponible — modo sin RAG: {chroma_err}")

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.getenv("SECRET_KEY", "hey_banco_dev_key")

CORS(app)

from routes.chat import chat_bp
app.register_blueprint(chat_bp, url_prefix="/api")

@app.route("/")
def index():
    return send_from_directory("templates", "index.html")

@app.route("/health")
def health():
    return {"status": "ok", "service": "Hey Chatbot MVP"}, 200

if __name__ == "__main__":
    port = int(os.getenv("FLASK_PORT", 5000))
    debug = os.getenv("FLASK_ENV", "development") == "development"
    logger.info(f"Corriendo en http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug)
